package dev.shubham.demospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
